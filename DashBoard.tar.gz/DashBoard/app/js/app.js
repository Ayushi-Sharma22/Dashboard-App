var app = angular.module("DashboardApp",['highcharts-ng','chart.js']);

app.controller('yipee',function($scope){
	$scope.a = 20;
	$scope.b = 30;
});


app.directive('datepicker', function() {
    return {
        restrict: 'A',
        require : 'ngModel',
        link : function (scope, element, attrs, ngModelCtrl) {
            $(function(){
                element.datepicker({
                    dateFormat:'dd/mm/yy',
                    onSelect:function (date) {
                        scope.$apply(function () {
                            ngModelCtrl.$setViewValue(date);
                        });
                    }
                });
            });
        }
    }
});

app.controller('selectChartCtrl',function($scope, $rootScope){
    "use strict";
    $scope.statuses = [{
        id: 1,
        name: "Line",
        controller: "LineCtrl",
        object: "line"     
    }, {
        id: 2,
        name: "Bar",
        controller: "BarCtrl",
        object: "bar"       
    }, {
        id: 3,
        name: "Doughnut",
        controller: "DoughnutCtrl",
        object: "doughnut"        
    }, {
        id: 4,
        name: "Radar",
        controller: "RadarCtrl",
        object: "radar"        
    }, {
        id: 5,
        name: "Pie",
        controller: "PieCtrl",
        object: "pie"
    },  {
        id: 6,
        name: "Polar Area",
        controller: "PolarCtrl"        
    },  {
        id: 7,
        name: "Dynamic",
        controller: "DynamicCtrl",
        object: "dynamic"        
    }];
    $scope.selected_status = 'Null';  

}).directive('bsDropdown', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            items: '=dropdownData',
            doSelect: '&selectVal',
            selectedItem: '=preselectedItem'
        },
        link: function (scope, element, attrs) {
            var html = '';
            switch (attrs.menuType) {
                case "button":
                    html += '<div class="btn-group"><button class="btn button-label btn-info">Action</button><button class="btn btn-info dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></button>';
                    break;
                default:
                    html += '<div class="dropdown"><a class="dropdown-toggle" role="button" data-toggle="dropdown"  href="javascript:;">Dropdown<b class="caret"></b></a>';
                    break;
            }
            html += '<ul class="dropdown-menu"><li ng-repeat="item in items"><a tabindex="-1" data-ng-click="selectVal(item)">{{item.name}}</a></li></ul></div>';
            element.append($compile(html)(scope));
            for (var i = 0; i < scope.items.length; i++) {
                if (scope.items[i].name === scope.selectedItem) {
                    scope.bSelectedItem = scope.items[i];
                    break;
                }
            }
            scope.selectVal = function (item) {

                // switch (attrs.menuType) {
                //     case "button":
                //         // $('button.button-label', element).html(item.name);
                //         break;
                //     default:
                //         $('a.dropdown-toggle', element).html('<b class="caret"></b> ' + item.name);
                //        break;
                // }
                scope.doSelect({
                    selectedVal: item.name,
                    control: item.controller,
                    object: item.object

                });
                // console.log(controller);
                //     console.log(object);
            };
            // scope.selectVal(scope.bSelectedItem);
            
        }
    };
});


app.controller('MainCtrl', function($scope, $http, $rootScope) {
 	$http.get("data/data.json").success(function(response){
    $rootScope.myData = response;
    console.log($scope.myData.price);
    console.log($scope.myData);
  });
});

app.controller("LineCtrl", function ($scope, $rootScope) {

  $scope.labels = ["January", "February", "March", "April", "May", "June", "July"];
  $scope.series = ['Series A', 'Series B'];
  $scope.data = $rootScope.myData;
  console.log($rootScope.myData);
  $scope.onClick = function (points, evt) {
    console.log(points, evt);
  };
});
          
app.controller("BarCtrl", function ($scope) {
  $scope.labels = ["January", "February", "March", "April", "May", "June", "July"];
  $scope.series = ['Series A', 'Series B'];

  $scope.data = [
    [65, 59, 80, 81, 56, 55, 40],
    [28, 48, 40, 19, 86, 27, 90]
  ];
});

app.controller("DoughnutCtrl", function ($scope) {
  $scope.labels = ["Download Sales", "In-Store Sales", "Mail-Order Sales"];
  $scope.data = [300, 500, 100];
});

app.controller("RadarCtrl", function ($scope) {
  $scope.labels =["Eating", "Drinking", "Sleeping", "Designing", "Coding", "Cycling", "Running"];

  $scope.data = [
    [65, 59, 90, 81, 56, 55, 40],
    [28, 48, 40, 19, 96, 27, 100]
  ];
});

app.controller("PieCtrl", function ($scope) {
  $scope.labels = ["Download Sales", "In-Store Sales", "Mail-Order Sales"];
  $scope.data = [300, 500, 100];
});

app.controller("PolarAreaCtrl", function ($scope) {
  $scope.labels = ["Download Sales", "In-Store Sales", "Mail-Order Sales", "Tele Sales", "Corporate Sales"];
  $scope.data = [300, 500, 100, 40, 120];
});
              
app.controller("BaseCtrl", function ($scope) {
    $scope.labels = ["Download Sales", "In-Store Sales", "Mail-Order Sales", "Tele Sales", "Corporate Sales"];
    $scope.data = [300, 500, 100, 40, 120];
    $scope.type = 'PolarArea';

    $scope.toggle = function () {
      $scope.type = $scope.type === 'PolarArea' ?
        'Pie' : 'PolarArea';
    };
});    